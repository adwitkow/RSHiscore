﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSHiscore {
    class Hiscore {

        public Skill[] Skills;
        public Minigame[] Minigames;

        public Hiscore(string response) {
            SetupArrays();

            string[] lines = response.TrimEnd('\n').Split('\n');

            for (int i = 0; i < lines.Length; i++) {
                string[] details = lines[i].Split(',');

                if (i < Skills.Length) {
                    ref Skill skill = ref Skills[i];
                    skill.Rank = int.Parse(details[0]);
                    skill.Level = int.Parse(details[1]);
                    skill.XP = int.Parse(details[2]);
                } else {
                    ref Minigame minigame = ref Minigames[i - Skills.Length];
                    minigame.Rank = int.Parse(details[0]);
                    minigame.Score = int.Parse(details[1]);
                }
            }
        }

        private void SetupArrays() {
            Skills = new Skill[] {
                new Skill("Overall"),
                new Skill("Attack"),
                new Skill("Defence"),
                new Skill("Strength"),
                new Skill("Hitpoints"),
                new Skill("Ranged"),
                new Skill("Prayer"),
                new Skill("Magic"),
                new Skill("Cooking"),
                new Skill("Woodcutting"),
                new Skill("Fletching"),
                new Skill("Fishing"),
                new Skill("Firemaking"),
                new Skill("Crafting"),
                new Skill("Smithing"),
                new Skill("Mining"),
                new Skill("Herblore"),
                new Skill("Agility"),
                new Skill("Thieving"),
                new Skill("Slayer"),
                new Skill("Farming"),
                new Skill("Runecraft"),
                new Skill("Hunter"),
                new Skill("Construction")
            };

            Minigames = new Minigame[] {
                new Minigame("Bounty Hunter - Hunter"),
                new Minigame("Bounty Hunter - Rogue"),
                new Minigame("LMS - Rank"),
                new Minigame("Clue Scrolls (all)"),
                new Minigame("Clue Scrolls (beginner)"),
                new Minigame("Clue Scrolls (easy)"),
                new Minigame("Clue Scrolls (medium)"),
                new Minigame("Clue Scrolls (hard)"),
                new Minigame("Clue Scrolls (elite)"),
                new Minigame("Clue Scrolls (master)")
            };
        }
    }
}
