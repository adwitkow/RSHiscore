﻿using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using System.Windows;

namespace RSHiscore {

    public partial class MainWindow : Window {

        private const string uri = "https://secure.runescape.com/m=hiscore_oldschool/index_lite.ws?player=";

        public MainWindow() {
            InitializeComponent();
        }

        private async void Button_Click(object sender, RoutedEventArgs e) {
            SearchButton.IsEnabled = false;

            SkillsDataGrid.Items.Clear();
            MinigamesDataGrid.Items.Clear();

            string response = await GetAsync(uri + PlayerNameTextBox.Text.Replace(' ', '_'));
            Hiscore hiscore = new Hiscore(response);

            foreach (Skill skill in hiscore.Skills) {
                SkillsDataGrid.Items.Add(skill);
            }

            foreach (Minigame minigame in hiscore.Minigames) {
                MinigamesDataGrid.Items.Add(minigame);
            }

            SearchButton.IsEnabled = true;
        }

        public async Task<string> GetAsync(string uri) {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;

            using (HttpWebResponse response = (HttpWebResponse)await request.GetResponseAsync())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream)) {
                return await reader.ReadToEndAsync();
            }
        }
    }
}
