﻿using RSHiscore.Score;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSHiscore {
    class Minigame : IScore{

        public string Name { get; set; }
        public int Rank { get; set; }
        public int Score { get; set; }

        public Minigame(string name, int rank, int score) {
            this.Name = name;
            this.Rank = rank;
            this.Score = score;
        }

        public Minigame(string name) : this(name, -1, -1) {}

        public bool IsEmpty() {
            return (string.IsNullOrEmpty(Name) || Score == -1);
        }
    }
}
