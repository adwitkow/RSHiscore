﻿using RSHiscore.Score;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSHiscore {
    class Skill : IScore {
        public string Name { get; set; }
        public int Rank { get; set; }
        public int Level { get; set; }
        public int XP { get; set; }

        public Skill(string name, int rank, int level, int xp) {
            this.Name = name;
            this.Rank = rank;
            this.Level = level;
            this.XP = xp;
        }

        public Skill(string name) : this(name, -1, -1, -1) {}

        public bool IsEmpty() {
            return (string.IsNullOrEmpty(Name) || Level == -1 || XP == -1);
        }
    }
}
